import { useState } from "react";
import { ethers } from "ethers";
import Web3Modal from "web3modal";

const SALE_ADDRESS = "ENDERECO_DO_CONTRATO"; // Substituir após deploy
const SALE_ABI = [
  "function buy(uint256 usdtAmount) external",
];

const USDT_ADDRESS = "0x55d398326f99059fF775485246999027B3197955";
const USDT_ABI = [
  "function approve(address spender, uint256 amount) external returns (bool)"
];

export default function Home() {
  const [account, setAccount] = useState(null);
  const [amount, setAmount] = useState("");

  async function connectWallet() {
    const web3Modal = new Web3Modal();
    const connection = await web3Modal.connect();
    const provider = new ethers.providers.Web3Provider(connection);
    const signer = provider.getSigner();
    setAccount(await signer.getAddress());
  }

  async function buyTokens() {
    if (!amount) return alert("Digite valor em USDT");

    const web3Modal = new Web3Modal();
    const connection = await web3Modal.connect();
    const provider = new ethers.providers.Web3Provider(connection);
    const signer = provider.getSigner();

    const usdt = new ethers.Contract(USDT_ADDRESS, USDT_ABI, signer);
    const decimals = 18;
    const value = ethers.utils.parseUnits(amount, decimals);
    await usdt.approve(SALE_ADDRESS, value);

    const sale = new ethers.Contract(SALE_ADDRESS, SALE_ABI, signer);
    const tx = await sale.buy(value);
    await tx.wait();

    alert("Compra realizada!");
  }

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      {!account ? (
        <button onClick={connectWallet}>Conectar Carteira</button>
      ) : (
        <div>
          <p>Carteira: {account}</p>
          <input
            type="text"
            placeholder="Valor em USDT"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
          <button onClick={buyTokens}>Comprar YHR</button>
        </div>
      )}
    </div>
  );
}
