const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();

  console.log("Deploying with account:", deployer.address);

  const tokenAddress = "0x6772Ed6ee3130bb80aFF555A601CDCE961097186"; // YHR
  const usdtAddress  = "0x55d398326f99059fF775485246999027B3197955"; // USDT BEP20
  const tokenDecimals = 18;

  const Sale = await hre.ethers.getContractFactory("YHRTokenSale_USDT");
  const sale = await Sale.deploy(tokenAddress, tokenDecimals, usdtAddress);

  await sale.deployed();
  console.log("Sale contract deployed at:", sale.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
