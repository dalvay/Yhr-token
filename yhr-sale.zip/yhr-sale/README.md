# YHR Token Sale

Venda do token **YHR** em troca de **USDT (BEP20)**.

## 🚀 Deploy na BSC Mainnet

1. Configure sua chave privada em `.env`:
   ```bash
   PRIVATE_KEY=SEU_PRIVATE_KEY
   ```

2. Instale dependências e compile:
   ```bash
   npm install
   npx hardhat compile
   ```

3. Deploy:
   ```bash
   npx hardhat run scripts/deploy.js --network bsc
   ```

4. Configure fases com `addPhase()` no contrato.

## 🌐 Frontend

```bash
cd frontend
npm install
npm run dev
```

Abra em http://localhost:3000 e conecte sua carteira.
